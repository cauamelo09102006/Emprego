using System;
using System.Text.RegularExpressions;

namespace BuscaEmprego.Entities
{
    public class Emprego
    {
        public int Id { get; set; }
        public string TituloEmprego { get; set; }
        public string DescricaoEmprego { get; set; }
        public string RequisitosEmprego { get; set; }
        public string LocalizacaoEmprego { get; set; }
        public string TipoContrato { get; set; }
        public decimal Salario { get; set; }
        public DateTime DataPublicacao { get; set; }

        // Método para validar se o campo TipoContrato é um número de telefone ou email
        public bool ValidarTipoContrato()
        {
            // Expressão regular para validar números de telefone e emails
            string regexPattern = @"^(\+\d{1,3}[- ]?)?\d{8,}$|^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";

            // Verifica se o valor de TipoContrato corresponde à expressão regular
            return Regex.IsMatch(TipoContrato, regexPattern);
     
        }
    }
}