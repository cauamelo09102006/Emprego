using System;
using Microsoft.EntityFrameworkCore;
using BuscaEmprego.Entities;
 
namespace BuscaEmprego.Context
{
    public class EmpregoContext : DbContext
    {
 
        public EmpregoContext(DbContextOptions<EmpregoContext> options) : base(options)
        { }
 
        public DbSet<Emprego> Emprego { get; set; }
    }
}