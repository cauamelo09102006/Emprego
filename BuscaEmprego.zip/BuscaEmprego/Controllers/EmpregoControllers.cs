using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using BuscaEmprego.Entities;
using BuscaEmprego.Context;
 
 
namespace BuscaEmprego.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmpregoController : ControllerBase
    {
        private readonly EmpregoContext _empregoContext;
       
        public EmpregoController(EmpregoContext context)
        {
            _empregoContext = context;
        }
       
        [HttpPost]
        public IActionResult Create(Emprego emprego)
        {
            emprego.DataPublicacao = emprego.DataPublicacao;
 
            _empregoContext.Add(emprego);
            _empregoContext.SaveChanges();
 
            return CreatedAtAction(nameof(BuscarPorId), new { id = emprego.Id }, emprego);
        }
 
        [HttpGet("{id}")]
        public IActionResult BuscarPorId(int id)
        {
            var emprego = _empregoContext.Emprego.Find(id);
 
            if (emprego == null)
                return NotFound();
 
            emprego.DataPublicacao = emprego.DataPublicacao;
            return Ok(emprego);
        }
 
        [HttpPut("{id}")]
        public IActionResult Editar(int id, Emprego emprego)
        {
            var empregoBanco = _empregoContext.Emprego.Find(id);
 
            if (empregoBanco == null)
                return NotFound();
 
            emprego.DataPublicacao = emprego.DataPublicacao;
 
            empregoBanco.TituloEmprego = emprego.TituloEmprego;
            empregoBanco.DescricaoEmprego = emprego.DescricaoEmprego;
            empregoBanco.RequisitosEmprego = emprego.RequisitosEmprego;
            empregoBanco.LocalizacaoEmprego = emprego.LocalizacaoEmprego;
            empregoBanco.TipoContrato = emprego.TipoContrato;
            empregoBanco.Salario = emprego.Salario;
 
            _empregoContext.Update(empregoBanco);
            _empregoContext.SaveChanges();
 
            return Ok(empregoBanco);
        }
 
        [HttpDelete("{id}")]
        public IActionResult Deletar(int id)
        {
            var empregoBanco = _empregoContext.Emprego.Find(id);
            if (empregoBanco == null)
                return NotFound();
 
            _empregoContext.Remove(empregoBanco);
            _empregoContext.SaveChanges();
 
            return NoContent();
        }
 
        [HttpGet("BuscarPorEmprego")]
        public IActionResult BuscarPorEmprego(string nome)
        {
            var empregos = _empregoContext.Emprego.Where(x => x.TituloEmprego.Contains(nome)).ToList();
            return Ok(empregos);
        }
 
        [HttpGet("BuscarTodos")]
        public IActionResult BuscarTodos()
        {
            var empregos = _empregoContext.Emprego.ToList();
            return Ok(empregos);
        }
    }
}