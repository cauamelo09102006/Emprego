using Microsoft.EntityFrameworkCore;
using BuscaEmprego.Context;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
 
var builder = WebApplication.CreateBuilder(args);
 
 
builder.Services.AddDbContext<EmpregoContext>(options =>
{
    var connectionString = builder.Configuration.GetConnectionString("ConexaoPadrao");
    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
});
 
 
builder.Services.AddControllers();
 
builder.Services.AddEndpointsApiExplorer();
 
builder.Services.AddSwaggerGen();
 
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyHeader()
        .AllowAnyMethod()
        .AllowAnyOrigin();
    });
});
 
var app = builder.Build();
 
if (app.Environment.IsDevelopment() || app.Environment.IsProduction())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
 
app.UseCors();
 
app.UseHttpsRedirection();
 
app.UseAuthorization();
 
app.MapControllers();
 
app.Run();