import blogFetch from "../axios/config";

import { useState, useEffect } from "react";

import { Link } from "react-router-dom";

import "./Home.css";

const Home = () => {
    const [posts, setPosts] = useState([]);

    const getPosts = async() => {
        try {

            const response = await blogFetch.get("/Emprego/BuscarTodos");
            
            const data = response.data;
            
            setPosts(data);
        } catch (error) {
            console.log(error);
        }

    };

    useEffect(() => {

        getPosts();

    }, []);

  return (
    <div className="home">
    <h1>Últimos posts</h1>
    {posts.length === 0 ? (
    <p>Carregando...</p> ) : (
        posts.map((post) => (
            <div className="post" key={post.id}>
                <h2>Emprego: {post.tituloEmprego}</h2>
                <p>Desrição: {post.descricaoEmprego}</p>
                <p>Requisitos: {post.requisitosEmprego}</p>
                <p>Localização: {post.localizacaoEmprego}</p>
                <p>Tipo de contrato: {post.tipoContrato}</p>
                <p>Salario: {post.salario}</p>
                <p>Data: {post.dataPublicacao}</p>
                <Link to={`/Emprego/BuscarTodos/${post.id}`} className="btn">Ler mais</Link>
            </div>
        ))
    )}
    </div>
  ); 
  
};

export default Home;