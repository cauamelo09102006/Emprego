import blogFetch from "../axios/config";

import { useState, useEffect } from "react";

import { useNavigate } from "react-router-dom";


import "./NewPost.css";

const NewPost = () => {
  const navigate = useNavigate();

  const [tituloEmprego, setTituloEmprego] = useState();
  const [descricaoEmprego, setDescricaoEmprego] = useState();
  const [requisitosEmprego, setRequisitosEmprego] = useState();
  const [localizacaoEmprego, setLocalizacaoEmprego] = useState();
  const [tipoContrato, setTipoContrato] = useState();
  const [salario, setSalario] = useState();
  const [dataPublicacao, setdataPublicacao] = useState(); 

  console.log(tituloEmprego);
  console.log(descricaoEmprego);
  console.log(requisitosEmprego);
  console.log(localizacaoEmprego);
  console.log(tipoContrato);
  console.log(salario);
  useEffect(() => {
    const currentDate = new Date().toISOString();
    setdataPublicacao(currentDate);
  }, []);

  const createPost = async (e) => {
    e.preventDefault();

    const post = { tituloEmprego, descricaoEmprego, requisitosEmprego, localizacaoEmprego, tipoContrato, salario, dataPublicacao};

    await blogFetch.post('/Emprego', {
         post,
    });

    navigate("/")
  };

  return ( <div className='new-post'>
    <h2>Inserir novo Post</h2>
    <form onSubmit={(e) => createPost(e)}>
      <div className="form-control">
        <label htmlFor="tituloEmprego">titulo Emprego</label>
        <input type="text" name="tituloEmprego" placeholder='Digite o titulo Emprego' id="tituloEmprego" onChange={(e) =>setTituloEmprego(e.target.value)} />
      </div>
      <div className="form-control">
        <label htmlFor="descricaoEmprego">Descrição</label>
        <textarea name="descricaoEmprego" id="descricaoEmprego" placeholder='digite a Descrição' onChange={(e) =>setDescricaoEmprego(e.target.value)}></textarea>
      </div>
      <div className="form-control">
        <label htmlFor="requisitosEmprego">requisitos</label>
        <textarea name="requisitosEmprego" id="requisitosEmprego" placeholder='digite o requisitos' onChange={(e) =>setRequisitosEmprego(e.target.value)}></textarea>
      </div>
      <div className="form-control">
        <label htmlFor="localizacaoEmprego">localização</label>
        <textarea name="localizacaoEmprego" id="localizacaoEmprego" placeholder='digite a localização' onChange={(e) =>setLocalizacaoEmprego(e.target.value)}></textarea>
      </div>
      <div className="form-control">
        <label htmlFor="btipoContratoody">contato</label>
        <textarea name="tipoContrato" id="tipoContrato" placeholder='digite o contato' onChange={(e) =>setTipoContrato(e.target.value)}></textarea>
      </div>
      <div className="form-control">
        <label htmlFor="salario">salario</label>
        <textarea name="salario" id="salario" placeholder='digite o salario' onChange={(e) =>setSalario(e.target.value)}></textarea>
      </div>
      <input type="submit" value="Criar Post" className='btn'/>
    </form>   
  </div>
  );
};

export default NewPost;