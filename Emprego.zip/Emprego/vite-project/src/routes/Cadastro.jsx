import "./Cadastro.css";


const Cadastro = () => {

  return (
    <div className="cadastro-container">
        <a href="index.html" className="voltar">&lt;</a>
        <h1>Cadastro</h1>
        <form id="cadastro-form">
            <div className="form-group">
                <label htmlFor="nome">Nome:</label>
                <input type="text" id="nome" name="nome" placeholder="Seu nome completo" required></input>
            </div>
            <div className="form-group">
                <label htmlFor="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Seu email" required></input>
            </div>
            <div className="form-group">
                <label htmlFor="senha">Senha:</label>
                <input type="password" id="senha" name="senha" placeholder="Sua senha" required></input>
            </div>
            <div className="form-group">
                <label htmlFor="telefone">Telefone:</label>
                <input type="tel" id="telefone" name="telefone" placeholder="Seu telefone" required></input>
            </div>
            <div className="form-group">
                <label htmlFor="endereco">Endereço:</label>
                <input type="text" id="endereco" name="endereco" placeholder="Seu endereço" required></input>
            </div>
            <button type="submit">Cadastrar</button>
        </form>
    </div>
  );
};

export default Cadastro